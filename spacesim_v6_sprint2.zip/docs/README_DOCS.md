Docs for humans & AI live here. See AI_INSTRUCTIONS.md, DEPLOYMENT_SYNC.md, PROJECT_PLAN.md, USER_GUIDE.md. Prompts in /prompts.
