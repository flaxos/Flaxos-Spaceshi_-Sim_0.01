def test_smoke():
    import sim_core.vec, sim_core.missile, sim_core.sensors
    assert True
